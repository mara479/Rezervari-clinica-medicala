package ro.clinicrezervari;

import org.junit.jupiter.api.Test;
import ro.clinicrezervari.db.DatabaseManager;
import ro.clinicrezervari.db.DoctorDao;
import ro.clinicrezervari.db.ProgramareDao;
import ro.clinicrezervari.model.Doctor;
import ro.clinicrezervari.model.Programare;
import ro.clinicrezervari.service.ProgramareService;

import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.assertThrows;
/**
 * Teste unitare pentru ProgramareService.
 */
public class ProgramareServiceTest {
    /**
     * Verifica faptul ca nu se permit suprapuneri:
     * aceeași data + ora + doctor pentru doua programari ACTIVE.
     *
     * @throws Exception daca apare o eroare in setup/test
     */
    @Test
    void nuPermiteSuprapuneri() throws Exception {
        DatabaseManager.initSchema();

        DoctorDao doctorDao = new DoctorDao();
        ProgramareDao programareDao = new ProgramareDao();

        // ca testul sa fie stabil=>asigurare ca exista doctor cu id=1
        // daca nu exista=>inserare unul
        if (doctorDao.findById(1) == null) {
            doctorDao.insert(new Doctor(0, "Dr. Test", "Test", "09:00-15:00"));
        }

        ProgramareService service = new ProgramareService(programareDao, doctorDao);

        Programare p1 = new Programare(0, 1, 1, LocalDate.now(), LocalTime.of(10, 0), "ACTIVA");
        Programare p2 = new Programare(0, 2, 1, LocalDate.now(), LocalTime.of(10, 0), "ACTIVA");

        service.creeazaProgramare(p1);

        assertThrows(IllegalStateException.class, () -> {
            try {
                service.creeazaProgramare(p2);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }
}

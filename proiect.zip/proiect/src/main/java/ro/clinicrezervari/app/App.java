package ro.clinicrezervari.app;

import ro.clinicrezervari.db.DatabaseManager;
import ro.clinicrezervari.ui.MainFrame;

import javax.swing.*;

/**
 * punct de intrare aplicatie
 * <p>
 *     initializeaza schema bazei de date (daca nu exista deja) si
 *     porneste interfata grafica Swing
 * </p>
 */
public class App {
    /**
     * pornire aplicatie
     * @param args argumente din linia de comanda
     */
    public static void main(String[] args) {
        //init tabele in DB
        DatabaseManager.initSchema();
        //se porneste UI pe Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            MainFrame f = new MainFrame();
            f.setVisible(true);
        });
    }
}

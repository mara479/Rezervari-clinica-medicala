package ro.clinicrezervari.db;

import ro.clinicrezervari.model.Doctor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO=Data Acess Object pentru tabelul DOCTOR
 * <p>
 *     contine op de creare, citire, update,stergere doctori
 * </p>
 */
public class DoctorDao {

    /**
     * inserare noi doctori in baza de date
     * @param d doctor inserat
     * @return ID doctor generat
     * @throws SQLException daca apare eroare la inserare
     */
    public Doctor insert(Doctor d) throws SQLException {
        String sql = "INSERT INTO DOCTOR(nume, specializare, program_disponibil) VALUES (?, ?, ?)";
        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, d.getNume());
            ps.setString(2, d.getSpecializare());
            ps.setString(3, d.getProgramDisponibil());
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) d.setId(rs.getInt(1));
            }
        }
        return d;
    }

    /**
     * returnare lista toti doctorii odonare alfab dupa nume
     * @returnlista doctori
     * @throws SQLException daca apare eroare SQL
     */
    public List<Doctor> findAll() throws SQLException {
        List<Doctor> list = new ArrayList<>();
        String sql = "SELECT id, nume, specializare, program_disponibil FROM DOCTOR ORDER BY nume";
        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new Doctor(
                        rs.getInt("id"),
                        rs.getString("nume"),
                        rs.getString("specializare"),
                        rs.getString("program_disponibil")
                ));
            }
        }
        return list;
    }

    /**
     * cautare doctor dupa ID
     * @param id id doctor
     * @return doctor gasit dupa id sau null altfel
     * @throws SQLException daca apare eroare SQL
     */
    public Doctor findById(int id) throws SQLException {
        String sql = "SELECT id, nume, specializare, program_disponibil FROM DOCTOR WHERE id=?";
        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                return new Doctor(
                        rs.getInt("id"),
                        rs.getString("nume"),
                        rs.getString("specializare"),
                        rs.getString("program_disponibil")
                );
            }
        }
    }

    /**
     * actualizare date ale unui doctor existent
     * @param d doctor cu datele noi id trebe valid
     * @throws SQLException daca apare eroare la update
     */
    public void update(Doctor d) throws SQLException {
        String sql = "UPDATE DOCTOR SET nume=?, specializare=?, program_disponibil=? WHERE id=?";
        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, d.getNume());
            ps.setString(2, d.getSpecializare());
            ps.setString(3, d.getProgramDisponibil());
            ps.setInt(4, d.getId());
            ps.executeUpdate();
        }
    }
}

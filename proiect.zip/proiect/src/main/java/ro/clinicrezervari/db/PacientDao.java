package ro.clinicrezervari.db;

import ro.clinicrezervari.model.Administrator;
import ro.clinicrezervari.model.Pacient;

import java.sql.*;

/**
 * data acess object pentru PACIENT
 * <p>
 *     op de creare,autentificare,verificare rol(admin)
 * </p>
 */
public class PacientDao {
    /**
     * Creeaza un pacient sau administrator in baza de date.
     *
     * @param nume numele utilizatorului
     * @param email email-ul (recomandat lowercase)
     * @param parola parola
     * @param isAdmin true pentru admin, false pentru pacient
     * @return obiect Pacient sau Administrator
     * @throws SQLException daca apare o eroare SQL (ex: email duplicat)
     */

    public Pacient insert(String nume, String email, String parola, boolean isAdmin) throws SQLException {
        String sql = "INSERT INTO PACIENT(nume, email, parola, is_admin) VALUES (?, ?, ?, ?)";
        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, nume);
            ps.setString(2, email.toLowerCase());
            ps.setString(3, parola);
            ps.setInt(4, isAdmin ? 1 : 0);
            ps.executeUpdate();

            int id;
            try (ResultSet rs = ps.getGeneratedKeys()) {
                rs.next();
                id = rs.getInt(1);
            }
            return isAdmin ? new Administrator(id, nume, email, parola) : new Pacient(id, nume, email, parola);
        }
    }
    /**
     * Autentifica utilizatorul dupa email si parola.
     *
     * @param email email introdus
     * @param parola parola introdusa
     * @return Pacient/Administrator daca este corect, altfel null
     * @throws SQLException daca apare o eroare SQL
     */
    public Pacient findByEmailAndPassword(String email, String parola) throws SQLException {
        String sql = "SELECT id, nume, email, parola, is_admin FROM PACIENT WHERE email=? AND parola=?";
        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, parola);

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;

                int id = rs.getInt("id");
                String nume = rs.getString("nume");
                int isAdmin = rs.getInt("is_admin");

                return (isAdmin == 1)
                        ? new Administrator(id, nume, email, parola)
                        : new Pacient(id, nume, email, parola);
            }
        }
    }

    /**
     * Verifica daca un utilizator este admin.
     *
     * @param pacientId id utilizator
     * @return true daca este admin, altfel false
     * @throws SQLException daca apare o eroare SQL
     */
    public boolean isAdmin(int pacientId) throws SQLException {
        String sql = "SELECT is_admin FROM PACIENT WHERE id=?";
        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, pacientId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return false;
                return rs.getInt(1) == 1;
            }
        }
    }
    /**
     * Verifica daca exista cel putin un admin in sistem.
     *
     * @return true daca exista admin, altfel false
     * @throws SQLException daca apare o eroare SQL
     */
    public boolean existsAnyAdmin() throws SQLException {
        String sql = "SELECT COUNT(*) FROM PACIENT WHERE is_admin=1";
        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            rs.next();
            return rs.getInt(1) > 0;
        }
    }
}

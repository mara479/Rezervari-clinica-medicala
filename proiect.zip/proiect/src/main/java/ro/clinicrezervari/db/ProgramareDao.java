package ro.clinicrezervari.db;

import ro.clinicrezervari.model.Programare;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO pentru tabela PROGRAMARE.
 * Include creare, listare, anulare si modificare data/ora.
 */
public class ProgramareDao {

    /**
     * Insereaza o programare in baza de date.
     *
     * @param p programarea
     * @return programarea cu id generat setat
     * @throws SQLException daca apare o eroare SQL
     */
    public Programare insert(Programare p) throws SQLException {
        String sql = "INSERT INTO PROGRAMARE(pacient_id, doctor_id, data_programare, ora_programare, durata_min, status) " +
                "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, p.getIdPacient());
            ps.setInt(2, p.getIdDoctor());
            ps.setDate(3, Date.valueOf(p.getData()));
            ps.setTime(4, Time.valueOf(p.getOra()));
            ps.setInt(5, 30);
            ps.setString(6, p.getStatus());
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) p.setId(rs.getInt(1));
            }
        }
        return p;
    }
    /**
     * Returneaza programarile unui pacient.
     *
     * @param pacientId id pacient
     * @return lista de programari
     * @throws SQLException daca apare o eroare SQL
     */
    public List<Programare> findByPacient(int pacientId) throws SQLException {
        String sql = "SELECT id, pacient_id, doctor_id, data_programare, ora_programare, status " +
                "FROM PROGRAMARE WHERE pacient_id=? ORDER BY data_programare DESC, ora_programare DESC";
        return selectList(sql, pacientId);
    }
    /**
     * Returneaza toate programarile.
     *
     * @return lista de programari
     * @throws SQLException daca apare o eroare SQL
     */
    public List<Programare> findAll() throws SQLException {
        String sql = "SELECT id, pacient_id, doctor_id, data_programare, ora_programare, status " +
                "FROM PROGRAMARE ORDER BY data_programare DESC, ora_programare DESC";
        return selectList(sql);
    }


    /**
     * Anuleaza o programare (status = ANULATA).
     * Nu sterge programarea din baza de date (stergere logica).
     *
     * @param programareId id programare
     * @throws SQLException daca apare o eroare SQL
     */
    public void cancel(int programareId) throws SQLException {
        String sql = "UPDATE PROGRAMARE SET status='ANULATA' WHERE id=?";
        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, programareId);
            ps.executeUpdate();
        }
    }

    /**
     * Modifica data si ora unei programari.
     *
     * @param programareId id programare
     * @param data data noua
     * @param ora ora noua
     * @throws SQLException daca apare o eroare SQL
     */
    public void updateDateTime(int programareId, LocalDate data, LocalTime ora) throws SQLException {
        String sql = "UPDATE PROGRAMARE SET data_programare=?, ora_programare=? WHERE id=?";

        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(data));
            ps.setTime(2, Time.valueOf(ora));
            ps.setInt(3, programareId);

            int updated = ps.executeUpdate();
            System.out.println("UPDATE programare id=" + programareId + " -> rows=" + updated);

            if (updated == 0) {
                throw new SQLException("Nu s-a modificat nimic in DB (id=" + programareId + ")");
            }
        }
    }


    /**
     * Verifica daca exista o programare activa in acelasi slot:
     * acelasi doctor + aceeasi data + aceeasi ora.
     *
     * @param doctorId id doctor
     * @param data data
     * @param ora ora
     * @param excludeProgramareId id programare de ignorat (la modificare) sau null
     * @return true daca exista suprapunere, altfel false
     * @throws SQLException daca apare o eroare SQL
     */
    public boolean existsOverlapActive(int doctorId, LocalDate data, LocalTime ora, Integer excludeProgramareId) throws SQLException {
        String sql =
                "SELECT COUNT(*) FROM PROGRAMARE " +
                        "WHERE doctor_id=? AND data_programare=? AND ora_programare=? AND status='ACTIVA' " +
                        (excludeProgramareId != null ? "AND id<>?" : "");

        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, doctorId);
            ps.setDate(2, Date.valueOf(data));
            ps.setTime(3, Time.valueOf(ora));
            if (excludeProgramareId != null) ps.setInt(4, excludeProgramareId);

            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }
    /**
     * Executa un SELECT parametrizat si intoarce lista de Programare.
     *
     * @param sql interogarea SQL
     * @param params parametri
     * @return lista de programari
     * @throws SQLException daca apare o eroare SQL
     */
    private List<Programare> selectList(String sql, Object... params) throws SQLException {
        List<Programare> list = new ArrayList<>();
        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Programare(
                            rs.getInt("id"),
                            rs.getInt("pacient_id"),
                            rs.getInt("doctor_id"),
                            rs.getDate("data_programare").toLocalDate(),
                            rs.getTime("ora_programare").toLocalTime(),
                            rs.getString("status")
                    ));
                }
            }
        }
        return list;
    }
}

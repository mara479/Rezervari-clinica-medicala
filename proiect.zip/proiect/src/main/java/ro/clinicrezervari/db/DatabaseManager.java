package ro.clinicrezervari.db;

import java.sql.*;

/**
 * manager pentru conexiune la baza de date si initializarea schemei
 * <p>
 *     este folosit Apache Derby
 *     creeare tabele Doctor,Pacient,Programare daca nu exista
 * </p>
 */
public final class DatabaseManager {
    /**URL JDBC pentru baza de date Derby*/

    private static final String DB_URL =
            "jdbc:derby:C:/Users/marai/IdeaProjects/proiect/dbdata.clinicdb;create=true";

    private DatabaseManager() {}
    //cls utilitara

    /**
     * obtinere conexiune la bada de date
     * @return conexiune JDBC
     * @throws SQLException daca nu se poate realiza conexiunea
     */
    public static Connection getConnection() throws SQLException {


        return DriverManager.getConnection(DB_URL);
    }

    /**
     * initializare schema (tabele) daca nu exista
     * @throws RuntimeException daca apare o eroare SQL la creare
     */
    public static void initSchema() {
        try (Connection con = getConnection(); Statement st = con.createStatement()) {

            if (!tableExists(con, "DOCTOR")) {
                st.executeUpdate(
                        "CREATE TABLE DOCTOR (" +
                                " id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY," +
                                " nume VARCHAR(120) NOT NULL," +
                                " specializare VARCHAR(120) NOT NULL," +
                                " program_disponibil VARCHAR(500)" +
                                ")"
                );
            }

            if (!tableExists(con, "PACIENT")) {
                st.executeUpdate(
                        "CREATE TABLE PACIENT (" +
                                " id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY," +
                                " nume VARCHAR(120) NOT NULL," +
                                " email VARCHAR(200) NOT NULL UNIQUE," +
                                " parola VARCHAR(200) NOT NULL," +
                                " is_admin SMALLINT NOT NULL DEFAULT 0" +
                                ")"
                );
            }

            if (!tableExists(con, "PROGRAMARE")) {
                st.executeUpdate(
                        "CREATE TABLE PROGRAMARE (" +
                                " id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY," +
                                " pacient_id INT NOT NULL," +
                                " doctor_id INT NOT NULL," +
                                " data_programare DATE NOT NULL," +
                                " ora_programare TIME NOT NULL," +
                                " durata_min INT NOT NULL DEFAULT 30," +
                                " status VARCHAR(20) NOT NULL DEFAULT 'ACTIVA'," +
                                " CONSTRAINT fk_prog_pac FOREIGN KEY (pacient_id) REFERENCES PACIENT(id)," +
                                " CONSTRAINT fk_prog_doc FOREIGN KEY (doctor_id) REFERENCES DOCTOR(id)" +
                                ")"
                );
            }

        } catch (SQLException e) {
            throw new RuntimeException("Eroare initSchema: " + e.getMessage(), e);
        }
    }

    /**
     * verificare existenta tabela in baza de date
     * @param con conexiune JDBC=sctiva
     * @param tableName nume tabel
     * @return true daca tabelu exista
     * @throws SQLException daca apar erori JDBC
     */
    private static boolean tableExists(Connection con, String tableName) throws SQLException {
        DatabaseMetaData md = con.getMetaData();
        try (ResultSet rs = md.getTables(null, null, tableName.toUpperCase(), null)) {
            return rs.next();
        }
    }
}

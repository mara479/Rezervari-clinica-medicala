package ro.clinicrezervari.model;

/**
 * Entitate Administrator.
 * Extinde Pacient si are drepturi suplimentare.
 */
public class Administrator extends Pacient {
    public Administrator() {}

    public Administrator(int id, String nume, String email, String parola) {
        super(id, nume, email, parola);
    }
}

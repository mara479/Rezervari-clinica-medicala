package ro.clinicrezervari.ui;

import ro.clinicrezervari.model.Pacient;
import ro.clinicrezervari.service.AuthService;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.function.BiConsumer;
/**
 * Ecran autentificare.
 * <p>
 * Permite login si navigare catre ecran creare cont.
 * </p>
 */
public class LoginPanel extends JPanel {

    /**
     * Creeaza panoul de login
     *
     * @param authService serviciu de autentificare
     * @param onSuccess callback apelat la login reusit (Pacient, esteAdmin)
     * @param onGoRegister callback pentru navigare spre RegisterPanel
     */
    public LoginPanel(AuthService authService,
                      BiConsumer<Pacient, Boolean> onSuccess,
                      Runnable onGoRegister) {

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Autentificare", SwingConstants.CENTER);
        title.setFont(title.getFont().deriveFont(22f));

        JTextField email = new JTextField(24);
        JPasswordField parola = new JPasswordField(24);

        JButton login = new JButton("Login");
        JButton register = new JButton("Creeaza cont");

        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        add(title, c);

        c.gridwidth = 1;
        c.gridx = 0; c.gridy = 1;
        add(new JLabel("Email:"), c);
        c.gridx = 1;
        add(email, c);

        c.gridx = 0; c.gridy = 2;
        add(new JLabel("Parola:"), c);
        c.gridx = 1;
        add(parola, c);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(register);
        buttons.add(login);

        c.gridx = 0; c.gridy = 3; c.gridwidth = 2;
        add(buttons, c);

        register.addActionListener(e -> onGoRegister.run());

        login.addActionListener(e -> {
            try {
                String em = email.getText().trim().toLowerCase();
                String pw = new String(parola.getPassword());

                if (em.isEmpty() || pw.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Completeaza email si parola.");
                    return;
                }

                Pacient p = authService.login(em, pw);
                if (p == null) {
                    JOptionPane.showMessageDialog(this, "Email sau parola incorecta.");
                    return;
                }
                boolean admin = authService.isAdmin(p);
                onSuccess.accept(p, admin);

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Eroare BD: " + ex.getMessage());
            }
        });
    }
}

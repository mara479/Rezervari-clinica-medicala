package ro.clinicrezervari.ui;

import ro.clinicrezervari.db.DoctorDao;
import ro.clinicrezervari.db.PacientDao;
import ro.clinicrezervari.db.ProgramareDao;
import ro.clinicrezervari.model.Pacient;
import ro.clinicrezervari.service.AuthService;
import ro.clinicrezervari.service.DoctorService;
import ro.clinicrezervari.service.ProgramareService;

import javax.swing.*;
import java.awt.*;
/**
 * Fereastra principala a aplicatie.
 * <p>
 * Foloseste CardLayout pentru comutare intre ecrane: Login, Register, Admin, Pacient
 * </p>
 */
public class MainFrame extends JFrame {

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel root = new JPanel(cardLayout);

    private final PacientDao pacientDao = new PacientDao();
    private final DoctorDao doctorDao = new DoctorDao();
    private final ProgramareDao programareDao = new ProgramareDao();

    private final AuthService authService;
    private final DoctorService doctorService;
    private final ProgramareService programareService;

    public MainFrame() {
        this.authService = new AuthService(pacientDao);
        this.doctorService = new DoctorService(doctorDao);
        this.programareService = new ProgramareService(programareDao, doctorDao);

        setTitle("Clinica - Sistem rezervari");
        setSize(1100, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        LoginPanel loginPanel = new LoginPanel(authService, this::onLoginSuccess, this::goRegister);
        RegisterPanel registerPanel = new RegisterPanel(authService, pacientDao, this::goLogin);

        root.add(loginPanel, "LOGIN");
        root.add(registerPanel, "REGISTER");

        setContentPane(root);
        cardLayout.show(root, "LOGIN");
    }

    private void onLoginSuccess(Pacient pacient, boolean isAdmin) {
        if (isAdmin) {
            AdminPanel adminPanel = new AdminPanel(doctorService, programareService, this::logout);
            root.add(adminPanel, "ADMIN");
            cardLayout.show(root, "ADMIN");
        } else {
            PacientPanel pacientPanel = new PacientPanel(pacient, doctorService, programareService, this::logout);
            root.add(pacientPanel, "PACIENT");
            cardLayout.show(root, "PACIENT");
        }
        revalidate();
        repaint();
    }

    private void logout() {
        goLogin();
    }

    private void goRegister() {
        cardLayout.show(root, "REGISTER");
    }

    private void goLogin() {
        cardLayout.show(root, "LOGIN");
        revalidate();
        repaint();
    }
}

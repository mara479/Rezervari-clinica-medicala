package ro.clinicrezervari.ui;

import ro.clinicrezervari.model.Doctor;
import ro.clinicrezervari.model.Pacient;
import ro.clinicrezervari.model.Programare;
import ro.clinicrezervari.service.DoctorService;
import ro.clinicrezervari.service.ProgramareService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * Panou grafic pentru pacient
 *
 * <p>
 *  permite pacientului
 * <ul>
 *     <li>vizualizarea doctorilor disponibili</li>
 *     <li>crearea unei programari</li>
 *     <li>modificarea datei si orei unei programari</li>
 *     <li>anularea unei programari</li>
 *     <li>vizualizarea istoricului programarilor</li>
 * </ul>
 * </p>
 */
public class PacientPanel extends JPanel {
    /**
     * Creeaza panoul pacientului.
     *
     * @param pacient pacientul autentificat
     * @param doctorService serviciu pentru doctori
     * @param programareService serviciu pentru programari
     * @param onLogout callback pentru logout
     */
    private final Pacient pacient;
    private final DoctorService doctorService;
    private final ProgramareService programareService;
    private final Runnable onLogout;

    private final DefaultTableModel doctorModel = new DefaultTableModel(
            new Object[]{"ID", "Nume", "Specializare", "Program"}, 0) {
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    private final JTable doctorTable = new JTable(doctorModel);
    /** Model tabel programari */
    private final DefaultTableModel progModel = new DefaultTableModel(
            new Object[]{"ID", "DoctorID", "Data", "Ora", "Status"}, 0) {
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    /** Tabel programari */
    private final JTable progTable = new JTable(progModel);
    /** Camp data pentru creare programare */
    private final JTextField dataField = new JTextField("2026-01-10", 10);
    /** Camp ora pentru creare programare */
    private final JTextField oraField = new JTextField("10:00", 10);
    /** Camp data noua pentru modificare */
    private final JTextField dataNouaField = new JTextField("2026-01-10", 10);
    /** Camp ora noua pentru modificare */
    private final JTextField oraNouaField = new JTextField("11:00", 10);

    public PacientPanel(Pacient pacient,
                        DoctorService doctorService,
                        ProgramareService programareService,
                        Runnable onLogout) {
        this.pacient = pacient;
        this.doctorService = doctorService;
        this.programareService = programareService;
        this.onLogout = onLogout;
        //JOptionPane.showMessageDialog(null, "PacientPanel constructor apelat");
        setLayout(new BorderLayout(10, 10));
        add(buildTopBar(), BorderLayout.NORTH);
        add(buildCenter(), BorderLayout.CENTER);
        // Cand selectez o programare, completeaza automat campurile pentru modificare
        progTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && progTable.getSelectedRow() >= 0) {
                int r = progTable.getSelectedRow();
                dataNouaField.setText(progModel.getValueAt(r, 2).toString()); // coloana Data
                oraNouaField.setText(progModel.getValueAt(r, 3).toString());  // coloana Ora
            }
        });
        refreshDoctori();
        refreshProgramari();
    }
    /**
     * Construieste bara superioara cu informatii despre pacient si logout.
     *
     * @return componenta grafica pentru top bar
     */
    private JComponent buildTopBar() {
        JPanel p = new JPanel(new BorderLayout());

        JLabel who = new JLabel("Pacient: " + pacient.getNume() + " (" + pacient.getEmail() + ")");
        who.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton logout = new JButton("Logout");
        logout.addActionListener(e -> onLogout.run());

        p.add(who, BorderLayout.WEST);
        p.add(logout, BorderLayout.EAST);
        return p;
    }
    /**
     * Construieste zona centrala a ecranului:
     * doctori in stanga, programari in dreapta.
     *
     * @return componenta centrala
     */
    private JComponent buildCenter() {
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setResizeWeight(0.55);

        JPanel left = new JPanel(new BorderLayout(8, 8));
        left.setBorder(BorderFactory.createTitledBorder("Doctori disponibili"));

        left.add(new JScrollPane(doctorTable), BorderLayout.CENTER);

        JPanel create = new JPanel(new FlowLayout(FlowLayout.LEFT));
        create.add(new JLabel("Data (YYYY-MM-DD):"));
        create.add(dataField);
        create.add(new JLabel("Ora (HH:MM):"));
        create.add(oraField);

        JButton createBtn = new JButton("Creeaza programare la doctor selectat");
        createBtn.addActionListener(e -> createProgramare());
        create.add(createBtn);

        JButton refreshDoc = new JButton("Refresh doctori");
        refreshDoc.addActionListener(e -> refreshDoctori());
        create.add(refreshDoc);

        left.add(create, BorderLayout.SOUTH);

        JPanel right = new JPanel(new BorderLayout(8, 8));
        right.setBorder(BorderFactory.createTitledBorder("Istoric programari"));

        right.add(new JScrollPane(progTable), BorderLayout.CENTER);

        JPanel actions = new JPanel(new GridLayout(2, 1));

// campuri + buton modificare
        JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        row1.add(new JLabel("Noua data:"));
        row1.add(dataNouaField);
        row1.add(new JLabel("Noua ora:"));
        row1.add(oraNouaField);

        JButton updateBtn = new JButton("Modifica data/ora selectata");
        updateBtn.addActionListener(e -> updateSelected());
        row1.add(updateBtn);

// butoane refresh + anulare
        JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton refreshProg = new JButton("Refresh programari");
        refreshProg.addActionListener(e -> refreshProgramari());

        JButton cancelBtn = new JButton("Anuleaza selectata");
        cancelBtn.addActionListener(e -> cancelSelected());

        row2.add(refreshProg);
        row2.add(cancelBtn);

        actions.add(row1);
        actions.add(row2);

        right.add(actions, BorderLayout.SOUTH);


        split.setLeftComponent(left);
        split.setRightComponent(right);
        return split;
    }
    /**
     * Incarca lista de doctori din baza de date.
     */
    private void refreshDoctori() {
        try {
            doctorModel.setRowCount(0);
            List<Doctor> docs = doctorService.getAllDoctori();
            for (Doctor d : docs) {
                doctorModel.addRow(new Object[]{
                        d.getId(), d.getNume(), d.getSpecializare(), d.getProgramDisponibil()
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Eroare la doctori: " + e.getMessage());
        }
    }
    /**
     * Incarca programarile pacientului.
     */
    private void refreshProgramari() {
        try {
            progModel.setRowCount(0);
            List<Programare> list = programareService.getProgramariPacient(pacient.getId());
            for (Programare p : list) {
                progModel.addRow(new Object[]{
                        p.getId(), p.getIdDoctor(), p.getData(), p.getOra(), p.getStatus()
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Eroare la programari: " + e.getMessage());
        }
    }
    /**
     * Creeaza o programare noua la doctorul selectat.
     */
    private void createProgramare() {
        int row = doctorTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Selecteaza un doctor din tabel.");
            return;
        }

        int doctorId = (int) doctorModel.getValueAt(row, 0);

        try {
            LocalDate data = LocalDate.parse(dataField.getText().trim());
            LocalTime ora = LocalTime.parse(oraField.getText().trim());

            Programare p = new Programare();
            p.setIdPacient(pacient.getId());
            p.setIdDoctor(doctorId);
            p.setData(data);
            p.setOra(ora);
            p.setStatus("ACTIVA");

            programareService.creeazaProgramare(p);

            JOptionPane.showMessageDialog(this, "Programare creata!");
            refreshProgramari();

        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Date/ora invalide sau eroare BD: " + ex.getMessage());
        }
    }
    /**
     * Anuleaza programarea selectata.
     */
    private void cancelSelected() {
        int row = progTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Selecteaza o programare din tabel.");
            return;
        }

        String status = (String) progModel.getValueAt(row, 4);
        if ("ANULATA".equalsIgnoreCase(status)) {
            JOptionPane.showMessageDialog(this, "Programarea este deja anulata.");
            return;
        }

        int progId = (int) progModel.getValueAt(row, 0);

        try {
            programareService.anuleazaProgramare(progId);
            JOptionPane.showMessageDialog(this, "Programare anulata!");
            refreshProgramari();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Eroare BD: " + e.getMessage());
        }
    }
    /**
     * Modifica data si ora programarii selectate.
     */
    private void updateSelected() {
        int row = progTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Selecteaza o programare din tabel.");
            return;
        }

        String status = (String) progModel.getValueAt(row, 4);
        if ("ANULATA".equalsIgnoreCase(status)) {
            JOptionPane.showMessageDialog(this, "Nu poti modifica o programare anulata.");
            return;
        }

        int progId = (int) progModel.getValueAt(row, 0);
        int doctorId = (int) progModel.getValueAt(row, 1);

        try {
            LocalDate dataNoua = LocalDate.parse(dataNouaField.getText().trim());
            LocalTime oraNoua = LocalTime.parse(oraNouaField.getText().trim());

            programareService.modificaDataOra(progId, doctorId, dataNoua, oraNoua);

            JOptionPane.showMessageDialog(this, "Programare modificata!");
            refreshProgramari();

        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Date/ora invalide sau eroare BD: " + ex.getMessage());
        }
    }



    }

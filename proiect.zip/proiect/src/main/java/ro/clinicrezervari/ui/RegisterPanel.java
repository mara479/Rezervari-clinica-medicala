package ro.clinicrezervari.ui;

import ro.clinicrezervari.db.PacientDao;
import ro.clinicrezervari.service.AuthService;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
/**
 * Ecran de inregistrare cont
 * <p>
 * Creeaza un cont de pacient sau administrator (in functie de checkbox).
 * </p>
 */
public class RegisterPanel extends JPanel {
    /**
     * Creeaza pano de inregistrare.
     *
     * @param authService serviciu pentru interogari ex: verificari rol
     * @param pacientDao DAO pentru inserare utilizator
     * @param onGoLogin callback pentru revenire la login
     */
    public RegisterPanel(AuthService authService, PacientDao pacientDao, Runnable onGoLogin) {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Creare cont", SwingConstants.CENTER);
        title.setFont(title.getFont().deriveFont(22f));

        JTextField nume = new JTextField(24);
        JTextField email = new JTextField(24);
        JPasswordField parola = new JPasswordField(24);

        JCheckBox adminBox = new JCheckBox("Cont administrator (doar daca nu exista deja admin)");

        JButton back = new JButton("Inapoi");
        JButton create = new JButton("Creeaza");

        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        add(title, c);

        c.gridwidth = 1;
        c.gridx = 0; c.gridy = 1; add(new JLabel("Nume:"), c);
        c.gridx = 1; add(nume, c);

        c.gridx = 0; c.gridy = 2; add(new JLabel("Email:"), c);
        c.gridx = 1; add(email, c);

        c.gridx = 0; c.gridy = 3; add(new JLabel("Parola:"), c);
        c.gridx = 1; add(parola, c);

        c.gridx = 0; c.gridy = 4; c.gridwidth = 2;
        add(adminBox, c);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(back);
        buttons.add(create);

        c.gridx = 0; c.gridy = 5; c.gridwidth = 2;
        add(buttons, c);

        back.addActionListener(e -> onGoLogin.run());

        create.addActionListener(e -> {
            try {
                String n = nume.getText().trim();
                String em = email.getText().trim().toLowerCase();
                String pw = new String(parola.getPassword());

                if (n.isEmpty() || em.isEmpty() || pw.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Completeaza toate campurile.");
                    return;
                }

               // boolean wantAdmin = adminBox.isSelected();
                //if (wantAdmin && authService.existsAdmin()) {
                 //   JOptionPane.showMessageDialog(this, "Exista deja administrator. Creeaza cont pacient.");
                 //   wantAdmin = false;
               // }
                boolean wantAdmin = adminBox.isSelected();

                pacientDao.insert(n, em, pw, wantAdmin);
                JOptionPane.showMessageDialog(this, "Cont creat! Te poti autentifica acum.");
                onGoLogin.run();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Eroare BD: " + ex.getMessage());
            }
        });

        // initial daca exista admin, dezactiv checkbox
       // try {
        //    if (authService.existsAdmin()) {
        //        adminBox.setSelected(false);
        //        adminBox.setEnabled(false);
         //   }
        //} catch (SQLException ignored) {}

    }
}

package ro.clinicrezervari.service;

import ro.clinicrezervari.db.PacientDao;
import ro.clinicrezervari.model.Pacient;

import java.sql.SQLException;
/**
 * Service pentru autentificare si verificare rol.
 * <p>
 * Interfata intre UI si DAO pentru login / rol admin.
 * </p>
 */
public class AuthService {
    private final PacientDao pacientDao;
    /**
     * Creeaza servicul de autentificare.
     *
     * @param pacientDao DAO pentru tabel PACIENT
     */
    public AuthService(PacientDao pacientDao) {
        this.pacientDao = pacientDao;
    }
    /**
     * Autentifica utilizatorul.
     *
     * @param email email-ul introdus
     * @param parola parola introdusa
     * @return Pacient/Administrator daca datele sunt corecte, altfel null
     * @throws SQLException daca apar erori la interogare
     */
    public Pacient login(String email, String parola) throws SQLException {
        return pacientDao.findByEmailAndPassword(email, parola);
    }
    /**
     * Verifica rolul de administrator pentru utilizator.
     *
     * @param pacient utilizatorul autentificat
     * @return true daca este admin, altfel false
     * @throws SQLException daca apar erori la interogare
     */
    public boolean isAdmin(Pacient pacient) throws SQLException {
        return pacientDao.isAdmin(pacient.getId());
    }

    /**
     * Verifica daca exista admin in sistem.
     *
     * @return true daca exista admin, altfel false
     * @throws SQLException daca apare o eroare SQL
     */

    public boolean existsAdmin() throws SQLException {
        return pacientDao.existsAnyAdmin();
    }
}

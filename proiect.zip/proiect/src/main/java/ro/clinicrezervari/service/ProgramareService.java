package ro.clinicrezervari.service;

import ro.clinicrezervari.db.DoctorDao;
import ro.clinicrezervari.db.ProgramareDao;
import ro.clinicrezervari.model.Doctor;
import ro.clinicrezervari.model.Programare;

import java.sql.SQLException;
import java.time.LocalTime;
import java.util.List;
/**
 * Service pentru gestionarea programarilor.
 * Contine regulile de business:
 * - nu permite suprapuneri (doctor + data + ora) pentru programari ACTIVE
 * - valideaza ca ora se afla in programul doctorului (format simplu interval)
 */
public class ProgramareService {

    private final ProgramareDao programareDao;
    private final DoctorDao doctorDao;
    /**
     * Creează serviciu de programari.
     * Constructor
     * @param programareDao DAO pentru tabela PROGRAMARE
     * @param doctorDao DAO pentru tabela DOCTOR (necesar la validare program)
     */
    public ProgramareService(ProgramareDao programareDao, DoctorDao doctorDao) {
        this.programareDao = programareDao;
        this.doctorDao = doctorDao;
    }

    /**
     * Creeaza programare noua daca:
     * - ora se afla în programul doctorului
     * - nu exista suprapunere cu alta programare activa
     *
     * @param p programarea de creat
     * @throws SQLException daca apare eroare DB
     * @throws IllegalStateException daca programarea este invalida (suprapunere / in afara program)
     */
    public void creeazaProgramare(Programare p) throws SQLException {
        Doctor d = doctorDao.findById(p.getIdDoctor());
        if (d == null) throw new IllegalStateException("Doctor inexistent.");

        // validare program disponibil
        if (!oraInProgramDoctor(d.getProgramDisponibil(), p.getOra())) {
            throw new IllegalStateException("Ora nu se afla in programul doctorului!");
        }

        // suprapuneri
        if (programareDao.existsOverlapActive(p.getIdDoctor(), p.getData(), p.getOra(), null)) {
            throw new IllegalStateException("Exista deja o programare la acea ora!");
        }

        programareDao.insert(p);
    }
    /**
     * Returnează programari pacient
     *
     * @param pacientId id pacient
     * @return lista programarilor pacientului
     * @throws SQLException daca apare eroare DB
     */
    public List<Programare> getProgramariPacient(int pacientId) throws SQLException {
        return programareDao.findByPacient(pacientId);
    }
    /**
     * Returneaza toate programarile (pentru administrator).
     *
     * @return lista tuturor programarilor
     * @throws SQLException daca apare eroare DB
     */
    public List<Programare> getToateProgramarile() throws SQLException {
        return programareDao.findAll();
    }
    /**
     * Anuleaza o programare existenta
     *
     * @param programareId id programare
     * @throws SQLException daca apare eroare DB
     */
    public void anuleazaProgramare(int programareId) throws SQLException {
        programareDao.cancel(programareId);
    }
    /**
     * Modifica data si ora programare daca:
     * - ora se afla in programul doctorului
     * - nu se suprapune cu alta programare activa
     *
     * @param programareId id programare
     * @param doctorId id doctor (al programarii)
     * @param data data noua
     * @param ora ora noua
     * @throws SQLException daca apare eroare DB
     * @throws IllegalStateException daca modificarea e invalida (suprapunere / in afara programului)
     */
    public void modificaDataOra(int programareId, int doctorId, java.time.LocalDate data, java.time.LocalTime ora) throws SQLException {
        Doctor d = doctorDao.findById(doctorId);
        if (d == null) throw new IllegalStateException("Doctor inexistent.");

        if (!oraInProgramDoctor(d.getProgramDisponibil(), ora)) {
            throw new IllegalStateException("Ora nu se afla in programul doctorului!");
        }

        if (programareDao.existsOverlapActive(doctorId, data, ora, programareId)) {
            throw new IllegalStateException("Suprapunere: exista deja o programare la acea ora!");
        }

        programareDao.updateDateTime(programareId, data, ora);
    }

    /**
     * Accepta format:
     *  - "09:00-15:00"
     *  - "L-V 09:00-15:00"/ "09:00-15:00"(validez doar interval orar)
     * Daca e null/empty -> consideram disponibil (ca sa nu blochezi proiectul).
     */
    static boolean oraInProgramDoctor(String program, LocalTime ora) {
        if (program == null) return true;
        program = program.trim();
        if (program.isEmpty()) return true;

        // daca incepe cu "L-V" / alt text, se ia ultima parte cu HH:MM-HH:MM
        String[] parts = program.split("\\s+");
        String interval = parts[parts.length - 1]; // ultima bucata

        if (!interval.contains("-")) return true;

        String[] hh = interval.split("-");
        if (hh.length != 2) return true;

        LocalTime start = LocalTime.parse(hh[0].trim());
        LocalTime end = LocalTime.parse(hh[1].trim());

        // ora exact la end NU intra
        return !ora.isBefore(start) && ora.isBefore(end);
    }
}

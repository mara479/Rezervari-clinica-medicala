package ro.clinicrezervari.service;

import ro.clinicrezervari.db.DoctorDao;
import ro.clinicrezervari.model.Doctor;

import java.sql.SQLException;
import java.util.List;
/**
 *  Service pentru gestionarea doctorilor
 * <p>
 * UI foloseste acest serviciu pentru a lista/adauga/modifica doctori
 * </p>
 */
public class DoctorService {
    private final DoctorDao doctorDao;
    /**
     * Constructor
     * @param doctorDao DAO pentru tabela DOCTOR
     */
    public DoctorService(DoctorDao doctorDao) {
        this.doctorDao = doctorDao;
    }
    /**
     * returnare toti doctorii
     * @return lista tuturor doctorilor
     * @throws SQLException daca apare eroare SQL
     */
    public List<Doctor> getAllDoctori() throws SQLException {
        return doctorDao.findAll();
    }
    /**
     * Returneaza un doctor dupa id.
     *
     * @param id id doctor
     * @return doctor sau null
     * @throws SQLException daca apare o eroare SQL
     */
    public Doctor getById(int id) throws SQLException {
        return doctorDao.findById(id);
    }
    /**
     * Adaugă un doctor nou.
     *
     * @param d doctorul de adaugat
     * @throws SQLException daca apare eroare SQL
     */
    public void adaugaDoctor(Doctor d) throws SQLException {
        doctorDao.insert(d);
    }
    /**
     * Modifica date doctor existent.
     *
     * @param d doctorul cu datele actualizate
     * @throws SQLException daca apare eroare SQL
     */
    public void modificaDoctor(Doctor d) throws SQLException {
        doctorDao.update(d);
    }
}
